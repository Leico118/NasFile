package ch.leico.nasfile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

class TransferService : Service() {
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        channel(this)
        val n = build(this, lastTitle, lastText, lastProgress)
        try {
            ServiceCompat.startForeground(
                this, ID, n,
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (wake == null) {
            wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NasFile:transfer").apply {
                    setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L)
                }
        }
        if (wifi == null) {
            runCatching {
                @Suppress("DEPRECATION")
                wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                    .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "NasFile:wifi").apply {
                        setReferenceCounted(false); acquire()
                    }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { wake?.release() }
        runCatching { wifi?.release() }
        wake = null; wifi = null
        super.onDestroy()
    }

    companion object {
        private const val ID = 4201
        private const val DONE_ID = 4202
        private const val CH = "transfers"
        @Volatile private var lastTitle = "Transfert en cours…"
        @Volatile private var lastText: String? = null
        @Volatile private var lastProgress: Float? = null
        private var active = 0

        private fun channel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(CH) == null) {
                    nm.createNotificationChannel(
                        NotificationChannel(CH, "Transferts", NotificationManager.IMPORTANCE_LOW)
                    )
                }
            }
        }

        private fun build(ctx: Context, title: String, text: String?, progress: Float?): Notification {
            val pi = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setContentIntent(pi)
                .setProgress(100, ((progress ?: 0f) * 100).toInt(), progress == null)
                .build()
        }

        @Synchronized
        fun start(ctx: Context, title: String) {
            active++
            lastTitle = title; lastText = null; lastProgress = null
            if (active == 1) runCatching {
                ContextCompat.startForegroundService(ctx, Intent(ctx, TransferService::class.java))
            }
        }

        @Synchronized
        fun stop(ctx: Context) {
            active = maxOf(0, active - 1)
            if (active == 0) ctx.stopService(Intent(ctx, TransferService::class.java))
        }

        fun update(ctx: Context, title: String, text: String?, progress: Float?) {
            lastTitle = title; lastText = text; lastProgress = progress
            channel(ctx)
            runCatching {
                ctx.getSystemService(NotificationManager::class.java).notify(ID, build(ctx, title, text, progress))
            }
        }

        fun done(ctx: Context, text: String) {
            channel(ctx)
            runCatching {
                val n = NotificationCompat.Builder(ctx, CH)
                    .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                    .setContentTitle("NasFile")
                    .setContentText(text)
                    .setAutoCancel(true)
                    .build()
                ctx.getSystemService(NotificationManager::class.java).notify(DONE_ID, n)
            }
        }
    }
}
