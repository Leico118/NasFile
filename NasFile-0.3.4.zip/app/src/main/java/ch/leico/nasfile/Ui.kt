@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package ch.leico.nasfile

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun App(vm: MainViewModel) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.toast) {
        val t = vm.toast ?: return@LaunchedEffect
        snack.showSnackbar(t)
        vm.toast = null
    }
    if (!vm.connected) LoginScreen(vm, snack) else BrowserScreen(vm, snack)
    vm.viewer?.let { (list, start) -> ImageViewer(vm, list, start) { vm.viewer = null } }
}

// ===================== Connexion =====================

@Composable
fun LoginScreen(vm: MainViewModel, snack: SnackbarHostState) {
    val p = vm.profile
    var local by rememberSaveable { mutableStateOf(p.local) }
    var remote by rememberSaveable { mutableStateOf(p.remote) }
    var qc by rememberSaveable { mutableStateOf(p.quickConnect) }
    var https by rememberSaveable { mutableStateOf(p.https) }
    var user by rememberSaveable { mutableStateOf(p.user) }
    var pass by rememberSaveable { mutableStateOf(p.pass) }
    var stay by rememberSaveable { mutableStateOf(p.remember) }
    var otp by rememberSaveable { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }

    fun go() = vm.connect(
        Profile(local, remote, qc, https, user.trim(), pass, stay, p.lastBase),
        otp.takeIf { vm.needOtp && it.isNotBlank() }
    )

    Scaffold(snackbarHost = { SnackbarHost(snack) }) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("NasFile", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Accès à ton NAS Synology, chez toi ou en 4G/5G", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(local, { local = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Adresse locale (Wi-Fi maison)") }, placeholder = { Text("192.168.1.20") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            OutlinedTextField(remote, { remote = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Adresse à distance (4G/5G)") }, placeholder = { Text("monnas.synology.me ou 100.x.x.x") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            OutlinedTextField(qc, { qc = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("ID QuickConnect (facultatif)") })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(https, { https = it })
                Spacer(Modifier.width(10.dp))
                Text("HTTPS (port 5001 au lieu de 5000)")
            }
            OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Utilisateur") })
            OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Mot de passe") },
                visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton({ showPass = !showPass }) {
                        Icon(if (showPass) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null)
                    }
                })
            if (vm.needOtp) {
                OutlinedTextField(otp, { otp = it }, Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("Code de validation en 2 étapes") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(stay, { stay = it })
                Text("Rester connecté")
            }
            if (vm.pendingShare.isNotEmpty()) Text(
                "${vm.pendingShare.size} fichier(s) en attente d'envoi : connecte-toi pour choisir le dossier",
                color = MaterialTheme.colorScheme.primary
            )
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = { go() },
                enabled = !vm.connecting && user.isNotBlank() &&
                        (local.isNotBlank() || remote.isNotBlank() || qc.isNotBlank()),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (vm.connecting) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(10.dp))
                    Text(vm.status.ifEmpty { "Connexion…" })
                } else Text("Se connecter")
            }
            TextButton({ help = !help }) { Text(if (help) "Masquer l'aide" else "Quelle adresse mettre ?") }
            if (help) {
                Card {
                    Text(
                        "• Adresse locale : l'IP du NAS chez toi (DSM → Panneau de configuration → Réseau).\n" +
                                "• Adresse à distance : ton nom DDNS (xxx.synology.me) avec le port ouvert sur la box, " +
                                "ou l'IP Tailscale du NAS (100.x.x.x) si Tailscale est installé.\n" +
                                "• Port différent : écris-le après « : » (ex. monnas.synology.me:5443).\n" +
                                "• L'appli essaie l'adresse locale, puis la distante, puis QuickConnect, automatiquement.",
                        Modifier.padding(14.dp), style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

// ===================== Navigateur =====================

private fun fileIcon(f: SynoFile): ImageVector = when {
    f.isDir -> Icons.Filled.Folder
    f.ext in MainViewModel.IMAGE_EXT -> Icons.Filled.Image
    f.ext in MainViewModel.VIDEO_EXT -> Icons.Filled.Movie
    f.ext in setOf("mp3", "flac", "wav", "m4a", "aac", "ogg", "opus", "wma") -> Icons.Filled.MusicNote
    f.ext == "pdf" -> Icons.Filled.PictureAsPdf
    f.ext in setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso") -> Icons.Filled.FolderZip
    f.ext == "apk" -> Icons.Filled.Android
    f.ext in setOf("txt", "doc", "docx", "odt", "rtf", "md", "xls", "xlsx", "ods", "csv", "ppt", "pptx") -> Icons.Filled.Description
    else -> Icons.Filled.InsertDriveFile
}

private fun hasThumb(f: SynoFile) = !f.isDir && (f.ext in MainViewModel.IMAGE_EXT || f.ext in MainViewModel.VIDEO_EXT)

fun fmtSize(b: Long): String {
    if (b < 1024) return "$b o"
    val u = arrayOf("Ko", "Mo", "Go", "To")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return String.format(Locale.FRENCH, "%.1f %s", v, u[i])
}

private val dateFmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.FRENCH)
fun fmtDate(s: Long): String = if (s <= 0) "" else dateFmt.format(Date(s * 1000))

@Composable
fun BrowserScreen(vm: MainViewModel, snack: SnackbarHostState) {
    var searching by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var sheetFor by remember { mutableStateOf<SynoFile?>(null) }
    var renameFor by remember { mutableStateOf<SynoFile?>(null) }
    var deleteFor by remember { mutableStateOf<SynoFile?>(null) }
    var newFolder by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) vm.upload(uris)
    }

    BackHandler(enabled = vm.viewer == null && (vm.path != null || searching)) {
        if (searching) { searching = false; vm.filter = "" } else vm.up()
    }

    val shown = remember(vm.files, vm.filter, vm.sort) {
        val q = vm.filter.trim().lowercase()
        val base = if (q.isEmpty()) vm.files else vm.files.filter { it.name.lowercase().contains(q) }
        val cmp: Comparator<SynoFile> = when (vm.sort) {
            1 -> compareByDescending { it.mtime }
            2 -> compareByDescending { it.size }
            else -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        }
        base.sortedWith(compareByDescending<SynoFile> { it.isDir }.then(cmp))
    }

    fun openItem(f: SynoFile) {
        if (!f.isDir && f.ext in MainViewModel.IMAGE_EXT && vm.api?.hasThumb() == true) {
            val imgs = shown.filter { !it.isDir && it.ext in MainViewModel.IMAGE_EXT }
            vm.viewer = imgs to imgs.indexOf(f).coerceAtLeast(0)
        } else vm.open(f)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            vm.path?.substringAfterLast('/') ?: "Dossiers partagés",
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(vm.connLabel, style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary)
                    }
                },
                navigationIcon = {
                    if (vm.path != null) IconButton({ vm.up() }) {
                        Icon(Icons.Filled.ArrowBack, "Retour")
                    }
                },
                actions = {
                    IconButton({ searching = !searching; if (!searching) vm.filter = "" }) {
                        Icon(if (searching) Icons.Filled.Close else Icons.Filled.Search, "Rechercher")
                    }
                    IconButton({ vm.toggleGrid() }) {
                        Icon(if (vm.grid) Icons.Filled.ViewList else Icons.Filled.GridView, "Affichage")
                    }
                    Box {
                        IconButton({ sortMenu = true }) { Icon(Icons.Filled.Sort, "Trier") }
                        DropdownMenu(sortMenu, { sortMenu = false }) {
                            listOf("Nom", "Date (récent)", "Taille").forEachIndexed { i, s ->
                                DropdownMenuItem(
                                    text = { Text(if (vm.sort == i) "✓  $s" else "     $s") },
                                    onClick = { vm.setSortMode(i); sortMenu = false })
                            }
                        }
                    }
                    Box {
                        IconButton({ moreMenu = true }) { Icon(Icons.Filled.MoreVert, "Plus") }
                        DropdownMenu(moreMenu, { moreMenu = false }) {
                            if (vm.path != null) DropdownMenuItem(
                                text = { Text("Nouveau dossier") },
                                leadingIcon = { Icon(Icons.Filled.CreateNewFolder, null) },
                                onClick = { moreMenu = false; newFolder = true })
                            DropdownMenuItem(
                                text = { Text("Dossiers partagés") },
                                leadingIcon = { Icon(Icons.Filled.Home, null) },
                                onClick = { moreMenu = false; vm.load(null) })
                            DropdownMenuItem(
                                text = { Text("Déconnexion") },
                                leadingIcon = { Icon(Icons.Filled.Logout, null) },
                                onClick = { moreMenu = false; vm.logout() })
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (vm.path != null) ExtendedFloatingActionButton(
                onClick = { picker.launch("*/*") },
                icon = { Icon(Icons.Filled.Upload, null) },
                text = { Text("Envoyer") }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            vm.busy?.let { label ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    vm.detail?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Spacer(Modifier.height(4.dp))
                    val pr = vm.progress
                    if (pr != null) LinearProgressIndicator(progress = { pr }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            if (vm.pendingShare.isNotEmpty()) {
                val n = vm.pendingShare.size
                Surface(color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (vm.path == null) "$n fichier(s) à envoyer : ouvre le dossier de destination"
                            else "Envoyer $n fichier(s) dans ce dossier",
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        TextButton({ vm.cancelShare() }) { Text("Annuler") }
                        Button({ vm.sendShareHere() }, enabled = vm.path != null && vm.busy == null) { Text("Envoyer ici") }
                    }
                }
            }
            Breadcrumbs(vm)
            if (searching) {
                OutlinedTextField(
                    vm.filter, { vm.filter = it },
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    singleLine = true, placeholder = { Text("Filtrer ce dossier") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) }
                )
            }
            PullToRefreshBox(
                isRefreshing = vm.loading && vm.files.isNotEmpty(),
                onRefresh = { vm.refresh() },
                modifier = Modifier.fillMaxSize()
            ) {
                when {
                    vm.loading && vm.files.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    shown.isEmpty() -> LazyColumn(Modifier.fillMaxSize()) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(48.dp), contentAlignment = Alignment.Center) {
                                Text(if (vm.filter.isBlank()) "Dossier vide" else "Aucun résultat",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    vm.grid -> LazyVerticalGrid(
                        columns = GridCells.Adaptive(110.dp),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 96.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(shown, key = { it.path }) { f ->
                            GridItem(vm, f, { openItem(f) }, { sheetFor = f })
                        }
                    }
                    else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
                        items(shown, key = { it.path }) { f ->
                            RowItem(vm, f, { openItem(f) }, { sheetFor = f })
                        }
                    }
                }
            }
        }
    }

    sheetFor?.let { f ->
        ModalBottomSheet(onDismissRequest = { sheetFor = null }) {
            Column(Modifier.navigationBarsPadding().padding(bottom = 12.dp)) {
                Text(f.name, Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                HorizontalDivider()
                SheetAction(Icons.Filled.OpenInNew, "Ouvrir") { sheetFor = null; openItem(f) }
                SheetAction(Icons.Filled.Download, if (f.isDir) "Télécharger (zip)" else "Télécharger sur le téléphone") {
                    sheetFor = null; vm.download(f)
                }
                if (!f.isDir) SheetAction(Icons.Filled.Share, "Partager") { sheetFor = null; vm.share(f) }
                if (vm.path != null) {
                    SheetAction(Icons.Filled.Edit, "Renommer") { sheetFor = null; renameFor = f }
                    SheetAction(Icons.Filled.Delete, "Supprimer") { sheetFor = null; deleteFor = f }
                }
            }
        }
    }

    renameFor?.let { f ->
        TextDialog("Renommer", f.name, "Renommer", { renameFor = null }) { renameFor = null; vm.rename(f, it) }
    }
    if (newFolder) {
        TextDialog("Nouveau dossier", "", "Créer", { newFolder = false }) { newFolder = false; vm.mkdir(it) }
    }
    deleteFor?.let { f ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text("Supprimer ?") },
            text = { Text("« ${f.name} » sera supprimé du NAS" + if (f.isDir) " avec tout son contenu." else ".") },
            confirmButton = {
                TextButton({ deleteFor = null; vm.delete(f) }) {
                    Text("Supprimer", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton({ deleteFor = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun Breadcrumbs(vm: MainViewModel) {
    val p = vm.path ?: return
    val parts = p.trim('/').split('/').filter { it.isNotEmpty() }
    val state = rememberLazyListState()
    LaunchedEffect(p) { if (parts.isNotEmpty()) state.scrollToItem(parts.size) }
    LazyRow(
        state = state,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        item {
            IconButton({ vm.load(null) }, Modifier.size(36.dp)) {
                Icon(Icons.Filled.Home, "Racine", Modifier.size(20.dp))
            }
        }
        itemsIndexed(parts) { i, name ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ChevronRight, null, Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
                val target = "/" + parts.subList(0, i + 1).joinToString("/")
                val last = i == parts.size - 1
                Text(
                    name,
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .combinedClickable(onClick = { if (!last) vm.load(target) })
                        .padding(horizontal = 6.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (last) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun Thumb(vm: MainViewModel, f: SynoFile, modifier: Modifier, iconSize: Int) {
    val loader = vm.imageLoader
    val url = if (hasThumb(f) && vm.api?.hasThumb() == true) vm.thumbUrl(f, "small") else null
    val icon = fileIcon(f)
    val tint = if (f.isDir) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Box(modifier, contentAlignment = Alignment.Center) {
        if (url != null && loader != null) {
            val ctx = LocalContext.current
            val req = remember(url) {
                val key = "s:${f.path}:${f.mtime}"
                ImageRequest.Builder(ctx).data(url).memoryCacheKey(key).diskCacheKey(key).crossfade(true).build()
            }
            val painter = rememberVectorPainter(icon)
            AsyncImage(
                model = req, contentDescription = null, imageLoader = loader,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                error = painter
            )
        } else {
            Icon(icon, null, Modifier.size(iconSize.dp), tint = tint)
        }
    }
}

@Composable
private fun RowItem(vm: MainViewModel, f: SynoFile, onClick: () -> Unit, onLong: () -> Unit) {
    val sub = if (f.isDir) fmtDate(f.mtime) else listOf(fmtSize(f.size), fmtDate(f.mtime)).filter { it.isNotEmpty() }.joinToString(" · ")
    ListItem(
        modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onLong),
        headlineContent = { Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        supportingContent = { if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall) },
        leadingContent = {
            Thumb(vm, f, Modifier.size(46.dp).clip(RoundedCornerShape(8.dp)), 30)
        },
        trailingContent = {
            IconButton(onLong) { Icon(Icons.Filled.MoreVert, "Actions") }
        }
    )
}

@Composable
private fun GridItem(vm: MainViewModel, f: SynoFile, onClick: () -> Unit, onLong: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(4.dp)
    ) {
        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Thumb(vm, f, Modifier.fillMaxWidth().aspectRatio(1f), 48)
        }
        Text(
            f.name, Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp),
            style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun SheetAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.combinedClickable(onClick = onClick),
        headlineContent = { Text(label) },
        leadingContent = { Icon(icon, null) }
    )
}

@Composable
private fun TextDialog(title: String, initial: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = {
            TextButton({ if (text.isNotBlank()) onOk(text) }, enabled = text.isNotBlank()) { Text(ok) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } }
    )
}

// ===================== Visionneuse photo =====================

@Composable
fun ImageViewer(vm: MainViewModel, list: List<SynoFile>, start: Int, onClose: () -> Unit) {
    if (list.isEmpty()) { onClose(); return }
    val pager = rememberPagerState(initialPage = start.coerceIn(0, list.size - 1)) { list.size }
    var zoomed by remember { mutableStateOf(false) }
    var chrome by remember { mutableStateOf(true) }
    BackHandler { onClose() }
    LaunchedEffect(pager.currentPage) { zoomed = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(
            state = pager,
            userScrollEnabled = !zoomed,
            beyondViewportPageCount = 1,
            key = { list[it].path },
            modifier = Modifier.fillMaxSize()
        ) { page ->
            ZoomImage(vm, list[page], pager.currentPage == page, { zoomed = it }, { chrome = !chrome })
        }
        if (chrome) {
            val f = list[pager.currentPage.coerceIn(0, list.size - 1)]
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .statusBarsPadding()
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClose) { Icon(Icons.Filled.ArrowBack, "Fermer", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text(f.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${pager.currentPage + 1} / ${list.size}", color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall)
                }
                IconButton({ vm.download(f) }) { Icon(Icons.Filled.Download, "Télécharger", tint = Color.White) }
                IconButton({ vm.share(f) }) { Icon(Icons.Filled.Share, "Partager", tint = Color.White) }
            }
            vm.busy?.let { label ->
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.55f)).navigationBarsPadding().padding(12.dp)
                ) {
                    Text(label, color = Color.White, style = MaterialTheme.typography.labelMedium)
                    vm.detail?.let { Text(it, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall) }
                    val pr = vm.progress
                    if (pr != null) LinearProgressIndicator(progress = { pr }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun ZoomImage(vm: MainViewModel, f: SynoFile, isCurrent: Boolean, onZoom: (Boolean) -> Unit, onTap: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(isCurrent) { if (!isCurrent) { scale = 1f; offset = Offset.Zero } }
    val loader = vm.imageLoader ?: return
    val ctx = LocalContext.current
    val url = vm.thumbUrl(f, "large") ?: return
    val req = remember(f.path, f.mtime) {
        val key = "l:${f.path}:${f.mtime}"
        ImageRequest.Builder(ctx).data(url)
            .memoryCacheKey(key).diskCacheKey(key)
            .placeholderMemoryCacheKey("s:${f.path}:${f.mtime}")
            .crossfade(true).build()
    }
    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(f.path) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                        onZoom(scale > 1f)
                    }
                )
            }
            .pointerInput(f.path) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val fingers = event.changes.count { it.pressed }
                        if (fingers >= 2 || scale > 1f) {
                            val ns = (scale * event.calculateZoom()).coerceIn(1f, 5f)
                            scale = ns
                            offset = if (ns <= 1.02f) Offset.Zero else offset + event.calculatePan()
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                    if (scale <= 1.02f) { scale = 1f; offset = Offset.Zero }
                    onZoom(scale > 1f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = req, contentDescription = f.name, imageLoader = loader,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale; scaleY = scale
                translationX = offset.x; translationY = offset.y
            }
        )
    }
}
