package ch.leico.nasfile

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

object QuickConnect {
    private val JSON = "application/json".toMediaType()

    private fun req(id: String, svc: String) = JSONObject()
        .put("version", 1).put("command", "get_server_info")
        .put("stop_when_error", false).put("stop_when_success", false)
        .put("id", svc).put("serverID", id).put("is_gofile", false)

    private fun post(client: OkHttpClient, url: String, body: String): String? = runCatching {
        client.newCall(Request.Builder().url(url).post(body.toRequestBody(JSON)).build())
            .execute().use { it.body?.string() }
    }.getOrNull()

    private fun parse(txt: String?): JSONArray? = txt?.let {
        runCatching { JSONArray(it) }.getOrNull() ?: runCatching { JSONArray().put(JSONObject(it)) }.getOrNull()
    }

    private fun ok(s: String?) = !s.isNullOrBlank() && s != "NULL" && s != "0.0.0.0"

    fun resolve(rawId: String, client: OkHttpClient): List<Pair<String, String>> {
        val id = rawId.trim().substringAfter("://").substringBefore('.').substringBefore('/')
        if (id.isBlank()) return emptyList()
        val body = JSONArray().put(req(id, "dsm_portal_https")).put(req(id, "dsm_portal")).toString()
        var arr = parse(post(client, "https://global.quickconnect.to/Serv.php", body)) ?: return emptyList()
        val first = arr.optJSONObject(0)
        val sites = first?.optJSONArray("sites")
        if (first != null && first.optInt("errno", -1) != 0 && sites != null && sites.length() > 0) {
            arr = parse(post(client, "https://${sites.optString(0)}/Serv.php", body)) ?: return emptyList()
        }
        val out = LinkedHashMap<String, String>()
        var relayRegion = ""
        var controlHost = ""
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optInt("errno", -1) != 0) continue
            val scheme = if (i == 0) "https" else "http"
            val server = o.optJSONObject("server") ?: continue
            val service = o.optJSONObject("service")
            val port = service?.optInt("port", 0)?.takeIf { it > 0 } ?: if (i == 0) 5001 else 5000
            val ext = service?.optInt("ext_port", 0)?.takeIf { it > 0 } ?: port
            server.optJSONArray("interface")?.let { ifs ->
                for (k in 0 until ifs.length()) {
                    val ip = ifs.optJSONObject(k)?.optString("ip")
                    if (ok(ip)) out["$scheme://$ip:$port/"] = "Local (QuickConnect)"
                }
            }
            server.optString("ddns").takeIf { ok(it) }?.let { out["$scheme://$it:$ext/"] = "DDNS (QuickConnect)" }
            server.optString("fqdn").takeIf { ok(it) }?.let { out["$scheme://$it:$ext/"] = "Nom de domaine (QuickConnect)" }
            server.optJSONObject("external")?.optString("ip")?.takeIf { ok(it) }?.let {
                out["$scheme://$it:$ext/"] = "IP publique (QuickConnect)"
            }
            o.optJSONObject("env")?.let {
                if (relayRegion.isBlank()) relayRegion = it.optString("relay_region")
                if (controlHost.isBlank()) controlHost = it.optString("control_host")
            }
        }
        if (ok(relayRegion)) {
            if (ok(controlHost)) {
                val t = JSONObject().put("version", 1).put("command", "request_tunnel")
                    .put("stop_when_error", false).put("stop_when_success", true)
                    .put("id", "dsm_portal_https").put("serverID", id).put("is_gofile", false)
                post(client, "https://$controlHost/Serv.php", t.toString())
            }
            out["https://$id.$relayRegion.quickconnect.to:443/"] = "Relais QuickConnect"
        }
        return out.map { it.key to it.value }
    }
}
