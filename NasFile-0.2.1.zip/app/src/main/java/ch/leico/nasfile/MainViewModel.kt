package ch.leico.nasfile

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import coil.ImageLoader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    private val client = Net.client()

    var profile by mutableStateOf(Prefs.load(app))
        private set
    var connected by mutableStateOf(false)
        private set
    var connecting by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
    var needOtp by mutableStateOf(false)
        private set
    var connLabel by mutableStateOf("")
        private set
    var imageLoader by mutableStateOf<ImageLoader?>(null)
        private set
    var api: SynoApi? = null
        private set

    var path by mutableStateOf<String?>(null)
        private set
    var files by mutableStateOf<List<SynoFile>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var filter by mutableStateOf("")
    var sort by mutableStateOf(Prefs.sort(app))
        private set
    var grid by mutableStateOf(Prefs.grid(app))
        private set
    var busy by mutableStateOf<String?>(null)
        private set
    var progress by mutableStateOf<Float?>(null)
        private set
    var toast by mutableStateOf<String?>(null)
    var viewer by mutableStateOf<Pair<List<SynoFile>, Int>?>(null)
    var pendingShare by mutableStateOf<List<Uri>>(emptyList())
        private set

    private val cache = HashMap<String, List<SynoFile>>()
    private var loadJob: Job? = null
    private var loadToken = 0
    private var reconnecting = false

    init {
        val p = profile
        if (p.remember && p.user.isNotBlank() && p.pass.isNotBlank() &&
            (p.local.isNotBlank() || p.remote.isNotBlank() || p.quickConnect.isNotBlank())
        ) connect(p)
    }

    fun setSortMode(v: Int) { sort = v; Prefs.setSort(ctx, v) }
    fun toggleGrid() { grid = !grid; Prefs.setGrid(ctx, grid) }

    // ---------- Connexion ----------

    fun connect(p: Profile, otp: String? = null) {
        if (connecting) return
        profile = p
        Prefs.save(ctx, p)
        connecting = true
        error = null
        viewModelScope.launch {
            try {
                val (a, label) = findServer(p)
                    ?: throw IOException("NAS injoignable. Vérifie les adresses ou ta connexion.")
                status = "Identification…"
                withContext(Dispatchers.IO) { a.login(p.user, p.pass, otp) }
                api = a
                connLabel = label
                if (imageLoader == null) imageLoader = ImageLoader.Builder(ctx)
                    .okHttpClient(client)
                    .respectCacheHeaders(false)
                    .crossfade(true)
                    .build()
                profile = p.copy(lastBase = a.base)
                Prefs.save(ctx, profile)
                needOtp = false
                connected = true
                cache.clear()
                val last = Prefs.lastUpload(ctx)
                load(if (pendingShare.isNotEmpty() && last.isNotBlank()) last else null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: SynoException) {
                if (e.code in setOf(403, 404, 406)) needOtp = true
                error = e.message
            } catch (e: Exception) {
                error = e.message ?: e.toString()
            } finally {
                connecting = false
                status = ""
            }
        }
    }

    private suspend fun findServer(p: Profile): Pair<SynoApi, String>? {
        val list = ArrayList<Pair<String, String>>()
        normalize(p.local, p.https)?.let { list += it to "Réseau local" }
        normalize(p.remote, p.https)?.let { b -> if (list.none { it.first == b }) list += b to "À distance" }
        if (p.lastBase.isNotBlank() && list.none { it.first == p.lastBase }) list += p.lastBase to "À distance"
        status = "Recherche du NAS…"
        race(list)?.let { return it }
        if (p.quickConnect.isNotBlank()) {
            status = "Recherche via QuickConnect…"
            val qc = withContext(Dispatchers.IO) { QuickConnect.resolve(p.quickConnect, client) }
            race(qc)?.let { return it }
        }
        return null
    }

    private suspend fun race(list: List<Pair<String, String>>): Pair<SynoApi, String>? {
        if (list.isEmpty()) return null
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val jobs = list.map { (b, l) ->
            scope.async {
                try { SynoApi(b, client).also { it.probe() } to l } catch (e: Exception) { null }
            }
        }
        var res: Pair<SynoApi, String>? = null
        for (j in jobs) {
            res = j.await()
            if (res != null) break
        }
        scope.cancel()
        return res
    }

    private fun normalize(raw: String, https: Boolean): String? {
        var s = raw.trim().trimEnd('/')
        if (s.isEmpty()) return null
        var scheme = if (https) "https" else "http"
        val m = Regex("^(https?)://", RegexOption.IGNORE_CASE).find(s)
        if (m != null) {
            scheme = m.groupValues[1].lowercase()
            s = s.substring(m.range.last + 1)
        }
        s = s.substringBefore('/')
        val hp = Regex("^(.+?)(?::(\\d+))?$").matchEntire(s) ?: return null
        val host = hp.groupValues[1]
        val port = hp.groupValues[2].ifEmpty { if (scheme == "https") "5001" else "5000" }
        return "$scheme://$host:$port/"
    }

    private fun silentReconnect() {
        if (reconnecting || connecting) return
        reconnecting = true
        val p = profile
        viewModelScope.launch {
            try {
                busy = "Changement de réseau, reconnexion…"
                val found = findServer(p)
                if (found == null) {
                    toast = "NAS injoignable pour le moment"
                } else {
                    val (a, label) = found
                    withContext(Dispatchers.IO) { a.login(p.user, p.pass, null) }
                    api = a
                    connLabel = label
                    profile = p.copy(lastBase = a.base)
                    Prefs.save(ctx, profile)
                    load(path)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast = e.message ?: "Reconnexion impossible"
            } finally {
                busy = null
                status = ""
                reconnecting = false
            }
        }
    }

    fun logout() {
        val a = api
        viewModelScope.launch(Dispatchers.IO) { a?.logout() }
        api = null
        connected = false
        files = emptyList()
        path = null
        cache.clear()
        profile = profile.copy(pass = "")
        Prefs.save(ctx, profile.copy(remember = profile.remember))
    }

    // ---------- Navigation ----------

    fun load(target: String?) {
        val a = api ?: return
        val key = target ?: "/"
        if (path != target) filter = ""
        path = target
        files = cache[key] ?: emptyList()
        loading = true
        val token = ++loadToken
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            try {
                val res = withContext(Dispatchers.IO) { if (target == null) a.listShares() else a.list(target) }
                cache[key] = res
                if (token == loadToken) files = res
            } catch (e: CancellationException) {
                throw e
            } catch (e: SynoException) {
                if (token == loadToken) toast = e.message
            } catch (e: IOException) {
                if (token == loadToken) silentReconnect()
            } catch (e: Exception) {
                if (token == loadToken) toast = e.message ?: "Erreur"
            } finally {
                if (token == loadToken) loading = false
            }
        }
    }

    fun refresh() = load(path)

    fun up(): Boolean {
        val p = path ?: return false
        val parent = p.substringBeforeLast('/', "")
        load(if (parent.isEmpty()) null else parent)
        return true
    }

    private fun invalidate() { cache.remove(path ?: "/") }

    // ---------- Opérations ----------

    private fun op(label: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = label
            progress = null
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast = e.message ?: "Erreur"
            } finally {
                busy = null
                progress = null
            }
        }
    }

    fun mkdir(name: String) {
        val dest = path ?: return
        op("Création du dossier…") {
            withContext(Dispatchers.IO) { api!!.createFolder(dest, name.trim()) }
            invalidate(); load(path)
        }
    }

    fun rename(f: SynoFile, name: String) = op("Renommage…") {
        withContext(Dispatchers.IO) { api!!.rename(f.path, name.trim()) }
        invalidate(); load(path)
    }

    fun delete(f: SynoFile) = op("Suppression de ${f.name}…") {
        withContext(Dispatchers.IO) { api!!.delete(f.path) }
        cache.remove(f.path)
        invalidate(); load(path)
    }

    fun receiveShare(uris: List<Uri>) {
        pendingShare = uris
        if (connected && path == null) {
            val last = Prefs.lastUpload(ctx)
            if (last.isNotBlank()) load(last)
        }
    }

    fun cancelShare() { pendingShare = emptyList() }

    fun sendShareHere() {
        val u = pendingShare
        if (u.isEmpty() || path == null) return
        pendingShare = emptyList()
        upload(u)
    }

    fun upload(uris: List<Uri>) {
        val dest = path ?: return
        Prefs.setLastUpload(ctx, dest)
        op("Envoi…") {
            val cr = ctx.contentResolver
            val tmpDir = File(ctx.cacheDir, "up").apply { mkdirs() }
            var n = 0
            for ((i, uri) in uris.withIndex()) {
                var name = "fichier_${System.currentTimeMillis()}"
                withContext(Dispatchers.IO) {
                    runCatching {
                        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                            if (c.moveToFirst()) c.getString(0)?.let { name = it }
                        }
                    }
                }
                busy = "Préparation ${i + 1}/${uris.size} : $name"
                progress = null
                val tmp = File(tmpDir, "u_${System.nanoTime()}")
                try {
                    withContext(Dispatchers.IO) {
                        val input = cr.openInputStream(uri) ?: throw IOException("Lecture impossible : $name")
                        input.use { inp -> FileOutputStream(tmp).use { out -> inp.copyTo(out, 256 * 1024) } }
                    }
                    busy = "Envoi ${i + 1}/${uris.size} : $name"
                    progress = 0f
                    withContext(Dispatchers.IO) {
                        api!!.upload(dest, name, tmp) { p -> progress = p }
                    }
                    n++
                } finally {
                    tmp.delete()
                }
            }
            toast = if (n > 1) "$n fichiers envoyés" else "Fichier envoyé"
            invalidate(); load(path)
        }
    }

    private fun fetch(f: SynoFile, out: OutputStream) {
        val a = api ?: throw IOException("Non connecté")
        fun once(): Boolean {
            val req = Request.Builder().url(a.downloadUrl(f.path, if (f.isDir) "download" else "open")).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) throw IOException("Erreur HTTP ${r.code}")
                val ct = r.header("Content-Type").orEmpty()
                if (ct.contains("json") && !f.name.endsWith(".json", true)) {
                    val t = r.peekBody(4096).string()
                    if (t.contains("\"success\":false")) {
                        val code = runCatching { JSONObject(t).getJSONObject("error").getInt("code") }.getOrDefault(-1)
                        if (code in SESSION_CODES) return false
                        throw SynoException(code, SynoApi.errorText(code, false))
                    }
                }
                val body = r.body ?: throw IOException("Réponse vide")
                val total = body.contentLength().takeIf { it > 0 } ?: f.size
                body.byteStream().use { input ->
                    val buf = ByteArray(128 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt().coerceAtMost(100)
                            if (pct != last) { last = pct; progress = pct / 100f }
                        }
                    }
                }
                return true
            }
        }
        if (!once()) {
            a.relogin()
            if (!once()) throw IOException("Session expirée")
        }
    }

    private fun localName(f: SynoFile) = if (f.isDir) "${f.name}.zip" else f.name

    private fun cacheFile(f: SynoFile): File {
        val dir = File(ctx.cacheDir, "open").apply { mkdirs() }
        val file = File(dir, localName(f))
        if (!f.isDir && file.exists() && f.size > 0 && file.length() == f.size) return file
        try {
            FileOutputStream(file).use { fetch(f, it) }
        } catch (e: Exception) {
            file.delete(); throw e
        }
        return file
    }

    fun download(f: SynoFile) = op("Téléchargement : ${localName(f)}") {
        val name = localName(f)
        val where = withContext(Dispatchers.IO) {
            if (Build.VERSION.SDK_INT >= 29) {
                val cr = ctx.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mimeOf(name))
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NasFile")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("Impossible de créer le fichier")
                try {
                    cr.openOutputStream(uri)!!.use { fetch(f, it) }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    cr.update(uri, values, null, null)
                } catch (e: Exception) {
                    cr.delete(uri, null, null); throw e
                }
                "Téléchargements/NasFile"
            } else {
                val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
                FileOutputStream(File(dir, name)).use { fetch(f, it) }
                dir.absolutePath
            }
        }
        toast = "Enregistré dans $where"
    }

    fun open(f: SynoFile) {
        if (f.isDir) { load(f.path); return }
        val a = api ?: return
        val mime = mimeOf(f.name)
        if (mime.startsWith("video/") || mime.startsWith("audio/")) {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(a.downloadUrl(f.path)), mime)
                .putExtra("title", f.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { ctx.startActivity(i); return } catch (e: ActivityNotFoundException) {}
        }
        op("Ouverture : ${f.name}") {
            val file = withContext(Dispatchers.IO) { cacheFile(f) }
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
            } catch (e: ActivityNotFoundException) {
                val c = Intent.createChooser(i, f.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { ctx.startActivity(c) } catch (e: Exception) { toast = "Aucune appli pour ouvrir ce fichier" }
            }
        }
    }

    fun share(f: SynoFile) = op("Préparation : ${localName(f)}") {
        val file = withContext(Dispatchers.IO) { cacheFile(f) }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND)
            .setType(mimeOf(file.name))
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, f.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun thumbUrl(f: SynoFile, size: String) = api?.thumbUrl(f.path, size)

    override fun onCleared() {
        api?.let { a -> CoroutineScope(Dispatchers.IO).launch { a.logout() } }
        super.onCleared()
    }

    companion object {
        val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "bmp", "webp", "heic", "heif", "tif", "tiff")
        val VIDEO_EXT = setOf("mp4", "mov", "mkv", "avi", "m4v", "wmv", "3gp", "webm", "ts", "mts", "m2ts")

        fun mimeOf(name: String): String {
            val ext = name.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "mkv" -> "video/x-matroska"
                "ts", "mts", "m2ts" -> "video/mp2t"
                "flac" -> "audio/flac"
                "heic" -> "image/heic"
                else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            }
        }
    }
}
