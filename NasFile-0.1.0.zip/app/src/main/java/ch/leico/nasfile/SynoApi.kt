package ch.leico.nasfile

import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class SynoException(val code: Int, message: String) : IOException(message)

data class SynoFile(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val size: Long,
    val mtime: Long
) {
    val ext: String get() = name.substringAfterLast('.', "").lowercase()
}

val SESSION_CODES = setOf(106, 107, 119)

class SynoApi(val base: String, val client: OkHttpClient) {
    private val versions = HashMap<String, IntArray>()
    private val paths = HashMap<String, String>()
    @Volatile var sid: String? = null
        private set
    private var account = ""
    private var password = ""
    private var otp: String? = null

    fun probe() {
        val fast = client.newBuilder()
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()
        val req = Request.Builder()
            .url("${base}webapi/query.cgi?api=SYNO.API.Info&version=1&method=query&query=all")
            .build()
        val j = exec(req, false, fast)
        val data = j.getJSONObject("data")
        val it = data.keys()
        while (it.hasNext()) {
            val k = it.next()
            val o = data.optJSONObject(k) ?: continue
            paths[k] = o.optString("path", "entry.cgi")
            versions[k] = intArrayOf(o.optInt("minVersion", 1), o.optInt("maxVersion", 1))
        }
        if (!paths.containsKey("SYNO.API.Auth") || !paths.containsKey("SYNO.FileStation.List"))
            throw SynoException(-2, "File Station introuvable sur ce NAS")
    }

    private fun ver(api: String, pref: Int): Int {
        val r = versions[api] ?: throw SynoException(-1, "Fonction non disponible sur ce NAS")
        return pref.coerceIn(r[0], maxOf(r[0], r[1]))
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun str(v: Int, s: String) = if (v >= 2) JSONObject.quote(s) else s
    private fun arr(v: Int, items: List<String>) = if (v >= 2) JSONArray(items).toString() else items.joinToString(",")
    private fun one(v: Int, s: String) = if (v >= 2) JSONArray(listOf(s)).toString() else s

    private fun buildUrl(api: String, params: Map<String, String>, withSid: Boolean = true): String {
        val sb = StringBuilder(base).append("webapi/").append(paths[api] ?: "entry.cgi")
        sb.append("?api=").append(api)
        params.forEach { (k, v) -> sb.append('&').append(k).append('=').append(enc(v)) }
        if (withSid) sid?.let { sb.append("&_sid=").append(enc(it)) }
        return sb.toString()
    }

    private fun exec(req: Request, auth: Boolean, c: OkHttpClient = client): JSONObject {
        c.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("Erreur HTTP ${r.code}")
            val txt = r.body?.string() ?: throw IOException("Réponse vide du NAS")
            val j = try { JSONObject(txt) } catch (e: JSONException) { throw IOException("Réponse inattendue (ce n'est pas un NAS Synology ?)") }
            if (!j.optBoolean("success")) {
                val err = j.optJSONObject("error")
                var code = err?.optInt("code", -1) ?: -1
                val inner = err?.optJSONArray("errors")?.optJSONObject(0)?.optInt("code", -1) ?: -1
                if (inner > 0) code = inner
                throw SynoException(code, errorText(code, auth))
            }
            return j
        }
    }

    private fun get(api: String, params: Map<String, String>): JSONObject =
        exec(Request.Builder().url(buildUrl(api, params)).build(), false)

    private fun <T> session(block: () -> T): T = try {
        block()
    } catch (e: SynoException) {
        if (e.code in SESSION_CODES) { relogin(); block() } else throw e
    }

    fun login(user: String, pass: String, otpCode: String?) {
        account = user; password = pass; otp = otpCode
        relogin()
    }

    @Synchronized
    fun relogin() {
        val v = ver("SYNO.API.Auth", 6)
        val p = linkedMapOf(
            "version" to "$v", "method" to "login",
            "account" to account, "passwd" to password,
            "session" to "FileStation", "format" to "sid"
        )
        otp?.takeIf { it.isNotBlank() }?.let { p["otp_code"] = it }
        sid = null
        val j = exec(Request.Builder().url(buildUrl("SYNO.API.Auth", p, false)).build(), true)
        sid = j.getJSONObject("data").getString("sid")
        otp = null
    }

    fun logout() {
        runCatching {
            val v = ver("SYNO.API.Auth", 6)
            get("SYNO.API.Auth", mapOf("version" to "$v", "method" to "logout", "session" to "FileStation"))
        }
        sid = null
    }

    fun listShares(): List<SynoFile> = session {
        val v = ver("SYNO.FileStation.List", 1)
        val j = get("SYNO.FileStation.List", mapOf(
            "version" to "$v", "method" to "list_share",
            "additional" to arr(v, listOf("time")),
            "sort_by" to str(v, "name")
        ))
        parse(j.optJSONObject("data")?.optJSONArray("shares"))
    }

    fun list(folder: String): List<SynoFile> = session {
        val v = ver("SYNO.FileStation.List", 1)
        val j = get("SYNO.FileStation.List", mapOf(
            "version" to "$v", "method" to "list",
            "folder_path" to str(v, folder),
            "additional" to arr(v, listOf("size", "time")),
            "sort_by" to str(v, "name")
        ))
        parse(j.optJSONObject("data")?.optJSONArray("files"))
    }

    fun downloadUrl(path: String, mode: String = "open"): String {
        val v = ver("SYNO.FileStation.Download", 1)
        return buildUrl("SYNO.FileStation.Download", mapOf(
            "version" to "$v", "method" to "download",
            "path" to one(v, path), "mode" to str(v, mode)
        ))
    }

    fun thumbUrl(path: String, size: String): String {
        val v = ver("SYNO.FileStation.Thumb", 1)
        return buildUrl("SYNO.FileStation.Thumb", mapOf(
            "version" to "$v", "method" to "get",
            "path" to str(v, path), "size" to str(v, size), "rotate" to "0"
        ))
    }

    fun hasThumb() = versions.containsKey("SYNO.FileStation.Thumb")

    fun createFolder(parent: String, name: String) { session {
        val v = ver("SYNO.FileStation.CreateFolder", 1)
        get("SYNO.FileStation.CreateFolder", mapOf(
            "version" to "$v", "method" to "create",
            "folder_path" to one(v, parent), "name" to one(v, name), "force_parent" to "false"
        ))
    } }

    fun rename(path: String, name: String) { session {
        val v = ver("SYNO.FileStation.Rename", 1)
        get("SYNO.FileStation.Rename", mapOf(
            "version" to "$v", "method" to "rename",
            "path" to one(v, path), "name" to one(v, name)
        ))
    } }

    fun delete(path: String) { session {
        val v = ver("SYNO.FileStation.Delete", 1)
        get("SYNO.FileStation.Delete", mapOf(
            "version" to "$v", "method" to "delete",
            "path" to one(v, path), "recursive" to "true"
        ))
    } }

    fun upload(folder: String, name: String, body: RequestBody) { session {
        val api = "SYNO.FileStation.Upload"
        val v = ver(api, 2)
        val mb = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("api", api)
            .addFormDataPart("version", "$v")
            .addFormDataPart("method", "upload")
            .addFormDataPart("path", folder)
            .addFormDataPart("create_parents", "true")
            .addFormDataPart("overwrite", if (v >= 3) "overwrite" else "true")
            .addFormDataPart("file", name, body)
            .build()
        val url = "${base}webapi/${paths[api] ?: "entry.cgi"}?_sid=${enc(sid ?: "")}"
        exec(Request.Builder().url(url).post(mb).build(), false)
    } }

    private fun parse(a: JSONArray?): List<SynoFile> {
        if (a == null) return emptyList()
        val out = ArrayList<SynoFile>(a.length())
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val add = o.optJSONObject("additional")
            out += SynoFile(
                name = o.optString("name"),
                path = o.optString("path"),
                isDir = o.optBoolean("isdir"),
                size = add?.optLong("size") ?: 0L,
                mtime = add?.optJSONObject("time")?.optLong("mtime") ?: 0L
            )
        }
        return out
    }

    companion object {
        fun errorText(code: Int, auth: Boolean): String {
            if (auth) when (code) {
                400 -> return "Identifiant ou mot de passe incorrect"
                401 -> return "Compte désactivé"
                402 -> return "Accès refusé pour ce compte"
                403 -> return "Code de validation en 2 étapes requis"
                404 -> return "Code de validation en 2 étapes incorrect"
                406 -> return "Validation en 2 étapes obligatoire"
                407 -> return "Ton adresse IP est bloquée par le NAS (trop d'essais)"
                408, 409, 410 -> return "Mot de passe expiré : change-le depuis DSM"
            }
            return when (code) {
                102, 103, 104 -> "Fonction non prise en charge par ce NAS ($code)"
                105 -> "Permission refusée"
                106 -> "Session expirée"
                107 -> "Session interrompue"
                119 -> "Session invalide"
                400, 401 -> "Opération impossible ($code)"
                402 -> "Le NAS est occupé, réessaie"
                403, 405, 407 -> "Permission refusée"
                408 -> "Fichier ou dossier introuvable"
                414 -> "Un élément porte déjà ce nom"
                415 -> "Quota disque dépassé"
                416 -> "Plus d'espace sur le NAS"
                418, 419 -> "Nom invalide"
                1100, 1101 -> "Impossible de créer le dossier"
                1200 -> "Impossible de renommer"
                900 -> "Impossible de supprimer"
                in 1800..1805 -> "Échec de l'envoi ($code)"
                else -> "Erreur du NAS ($code)"
            }
        }
    }
}
