package ch.leico.nasfile

import android.content.Context

data class Profile(
    val local: String = "",
    val remote: String = "",
    val quickConnect: String = "",
    val https: Boolean = false,
    val user: String = "",
    val pass: String = "",
    val remember: Boolean = true,
    val lastBase: String = ""
)

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("nasfile", Context.MODE_PRIVATE)

    fun load(ctx: Context): Profile {
        val p = sp(ctx)
        return Profile(
            local = p.getString("local", "") ?: "",
            remote = p.getString("remote", "") ?: "",
            quickConnect = p.getString("qc", "") ?: "",
            https = p.getBoolean("https", false),
            user = p.getString("user", "") ?: "",
            pass = p.getString("pass", "") ?: "",
            remember = p.getBoolean("remember", true),
            lastBase = p.getString("lastBase", "") ?: ""
        )
    }

    fun save(ctx: Context, pr: Profile) {
        sp(ctx).edit()
            .putString("local", pr.local)
            .putString("remote", pr.remote)
            .putString("qc", pr.quickConnect)
            .putBoolean("https", pr.https)
            .putString("user", pr.user)
            .putString("pass", if (pr.remember) pr.pass else "")
            .putBoolean("remember", pr.remember)
            .putString("lastBase", pr.lastBase)
            .apply()
    }

    fun sort(ctx: Context) = sp(ctx).getInt("sort", 0)
    fun setSort(ctx: Context, v: Int) = sp(ctx).edit().putInt("sort", v).apply()
    fun grid(ctx: Context) = sp(ctx).getBoolean("grid", false)
    fun setGrid(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("grid", v).apply()
}
